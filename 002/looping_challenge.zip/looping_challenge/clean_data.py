import json

# Task 1
list_of_10_photos = []
list_of_100_photos = []

# Task 2
list_of_10_random_photos = []
list_of_100_random_photos = []

def main():
    photosFile = open('photos.json', 'r')
    photo_list = json.load(photosFile)
    # Put your code here
    # e.g. to print it
    # print(photo_list)

    # set index
    # while CONDITIONAL:
        # ADD TO LIST


if __name__ == "__main__":
    main()